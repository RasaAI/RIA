import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MarketRiskComponent } from './Liquidity-risk.component';

const routes: Routes = [
  { path: '', component: MarketRiskComponent }  // Route for the dashboard page
];

@NgModule({
  imports: [RouterModule.forChild(routes)],  // Use forChild since it's a feature module
  exports: [RouterModule]
})
export class MarketRiskRoutingModule { }
