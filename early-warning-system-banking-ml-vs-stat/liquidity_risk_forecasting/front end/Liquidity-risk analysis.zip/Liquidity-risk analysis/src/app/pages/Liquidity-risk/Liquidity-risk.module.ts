// market-risk.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { MarketRiskComponent } from './Liquidity-risk.component';

const routes: Routes = [
  { path: '', component: MarketRiskComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MarketRiskComponent
  ]
})
export class MarketRiskModule {}
